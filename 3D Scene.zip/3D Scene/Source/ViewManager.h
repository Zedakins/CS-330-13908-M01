///////////////////////////////////////////////////////////////////////////////
// ViewManager.h
// ============
// Manage the viewing of 3D objects within the viewport.
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//  Updated for CS-330 Final Project
///////////////////////////////////////////////////////////////////////////////

#pragma once

#include "ShaderManager.h"
#include "camera.h"
#include "GLFW/glfw3.h"

class ViewManager
{
public:
    // Constructor
    ViewManager(ShaderManager* pShaderManager);

    // Destructor
    ~ViewManager();

    // Creates the OpenGL display window
    GLFWwindow* CreateDisplayWindow(const char* windowTitle);

    // Prepares the 3D to 2D scene conversion
    void PrepareSceneView();

    // Mouse position callback for adjusting camera orientation
    static void Mouse_Position_Callback(GLFWwindow* window, double xMousePos, double yMousePos);

    // Mouse scroll callback for adjusting camera zoom
    static void Mouse_Scroll_Callback(GLFWwindow* window, double xOffset, double yOffset);

private:
    // Processes keyboard events for camera movement and projection toggling
    void ProcessKeyboardEvents();

    // Pointer to the shader manager
    ShaderManager* m_pShaderManager;

    // Pointer to the active OpenGL window
    GLFWwindow* m_pWindow;
};
