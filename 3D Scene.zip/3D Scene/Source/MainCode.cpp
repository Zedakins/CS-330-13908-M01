#include <iostream>
#include <cstdlib>
#include <GL/glew.h>
#include "GLFW/glfw3.h"

#include "SceneManager.h"
#include "ViewManager.h"
#include "ShaderManager.h"

namespace
{
    const char* const WINDOW_TITLE = "3D Scene Viewer";
    GLFWwindow* g_Window = nullptr;

    SceneManager* g_SceneManager = nullptr;
    ShaderManager* g_ShaderManager = nullptr;
    ViewManager* g_ViewManager = nullptr;
}

bool InitializeGLFW();
bool InitializeGLEW();

int main(int argc, char* argv[])
{
    if (!InitializeGLFW()) return EXIT_FAILURE;

    g_ShaderManager = new ShaderManager();
    g_ViewManager = new ViewManager(g_ShaderManager);

    g_Window = g_ViewManager->CreateDisplayWindow(WINDOW_TITLE);
    if (!g_Window) return EXIT_FAILURE;

    if (!InitializeGLEW()) return EXIT_FAILURE;

    g_ShaderManager->LoadShaders("../../Utilities/shaders/vertexShader.glsl", "../../Utilities/shaders/fragmentShader.glsl");
    g_ShaderManager->use();

    g_SceneManager = new SceneManager(g_ShaderManager);
    g_SceneManager->PrepareScene();

    while (!glfwWindowShouldClose(g_Window))
    {
        glEnable(GL_DEPTH_TEST);
        glClearColor(0.1f, 0.1f, 0.1f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        g_ViewManager->PrepareSceneView();
        g_SceneManager->RenderScene();

        glfwSwapBuffers(g_Window);
        glfwPollEvents();
    }

    delete g_SceneManager;
    delete g_ViewManager;
    delete g_ShaderManager;
    glfwTerminate();

    return EXIT_SUCCESS;
}

bool InitializeGLFW()
{
    if (!glfwInit())
    {
        std::cerr << "GLFW initialization failed\n";
        return false;
    }

    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 6);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

#ifdef __APPLE__
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#endif

    return true;
}

bool InitializeGLEW()
{
    GLenum GLEWInitResult = glewInit();
    if (GLEW_OK != GLEWInitResult)
    {
        std::cerr << glewGetErrorString(GLEWInitResult) << std::endl;
        return false;
    }

    std::cout << "INFO: OpenGL Successfully Initialized\n";
    std::cout << "INFO: OpenGL Version: " << glGetString(GL_VERSION) << "\n" << std::endl;

    return true;
}
