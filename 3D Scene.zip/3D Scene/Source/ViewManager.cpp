#include "ViewManager.h"

// GLM Math Header inclusions
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>

// Global variables and defines
namespace
{
    const int WINDOW_WIDTH = 1000;        // Width of the window
    const int WINDOW_HEIGHT = 800;       // Height of the window
    const char* g_ViewName = "view";     // View matrix variable name
    const char* g_ProjectionName = "projection"; // Projection matrix variable name

    Camera* g_pCamera = nullptr;         // Pointer to the camera object

    float gLastX = WINDOW_WIDTH / 2.0f;  // Last X position of the mouse
    float gLastY = WINDOW_HEIGHT / 2.0f; // Last Y position of the mouse
    bool gFirstMouse = true;             // Flag for first mouse movement

    float gDeltaTime = 0.0f;             // Time between frames
    float gLastFrame = 0.0f;             // Time of the last frame

    bool bOrthographicProjection = false; // Toggle for orthographic projection
}

/***********************************************************
 *  ViewManager()
 *
 *  Constructor initializes member variables and sets default
 *  camera parameters.
 ***********************************************************/
ViewManager::ViewManager(ShaderManager* pShaderManager)
    : m_pShaderManager(pShaderManager), m_pWindow(nullptr)
{
    g_pCamera = new Camera();
    g_pCamera->Position = glm::vec3(0.0f, 5.0f, 12.0f);
    g_pCamera->Front = glm::vec3(0.0f, -0.5f, -1.0f);
    g_pCamera->Up = glm::vec3(0.0f, 1.0f, 0.0f);
    g_pCamera->Zoom = 45.0f;
}

/***********************************************************
 *  ~ViewManager()
 *
 *  Destructor cleans up allocated resources.
 ***********************************************************/
ViewManager::~ViewManager()
{
    if (g_pCamera != nullptr) delete g_pCamera;
}

/***********************************************************
 *  CreateDisplayWindow()
 *
 *  Creates the main OpenGL window using GLFW.
 ***********************************************************/
GLFWwindow* ViewManager::CreateDisplayWindow(const char* windowTitle)
{
    GLFWwindow* window = glfwCreateWindow(WINDOW_WIDTH, WINDOW_HEIGHT, windowTitle, nullptr, nullptr);
    if (!window)
    {
        std::cerr << "Failed to create GLFW window\n";
        glfwTerminate();
        return nullptr;
    }

    glfwMakeContextCurrent(window);

    // Set callbacks for mouse events
    glfwSetCursorPosCallback(window, &ViewManager::Mouse_Position_Callback);
    glfwSetScrollCallback(window, &ViewManager::Mouse_Scroll_Callback);

    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

    m_pWindow = window;
    return window;
}

/***********************************************************
 *  Mouse_Position_Callback()
 *
 *  Handles mouse movement to adjust camera orientation.
 ***********************************************************/
void ViewManager::Mouse_Position_Callback(GLFWwindow* window, double xMousePos, double yMousePos)
{
    if (gFirstMouse)
    {
        gLastX = static_cast<float>(xMousePos);
        gLastY = static_cast<float>(yMousePos);
        gFirstMouse = false;
    }

    float xOffset = static_cast<float>(xMousePos) - gLastX;
    float yOffset = gLastY - static_cast<float>(yMousePos);

    gLastX = static_cast<float>(xMousePos);
    gLastY = static_cast<float>(yMousePos);

    if (g_pCamera)
    {
        g_pCamera->ProcessMouseMovement(xOffset, yOffset);
    }
}

/***********************************************************
 *  Mouse_Scroll_Callback()
 *
 *  Handles mouse scroll to adjust camera zoom.
 ***********************************************************/
void ViewManager::Mouse_Scroll_Callback(GLFWwindow* window, double xOffset, double yOffset)
{
    if (g_pCamera)
    {
        g_pCamera->ProcessMouseScroll(static_cast<float>(yOffset));
    }
}

/***********************************************************
 *  ProcessKeyboardEvents()
 *
 *  Handles keyboard inputs for camera navigation and view toggling.
 ***********************************************************/
void ViewManager::ProcessKeyboardEvents()
{
    if (!m_pWindow || !g_pCamera) return;

    // Close the application if Escape is pressed
    if (glfwGetKey(m_pWindow, GLFW_KEY_ESCAPE) == GLFW_PRESS)
    {
        glfwSetWindowShouldClose(m_pWindow, true);
    }

    // Camera movement
    if (glfwGetKey(m_pWindow, GLFW_KEY_W) == GLFW_PRESS)
        g_pCamera->ProcessKeyboard(FORWARD, gDeltaTime);
    if (glfwGetKey(m_pWindow, GLFW_KEY_S) == GLFW_PRESS)
        g_pCamera->ProcessKeyboard(BACKWARD, gDeltaTime);
    if (glfwGetKey(m_pWindow, GLFW_KEY_A) == GLFW_PRESS)
        g_pCamera->ProcessKeyboard(LEFT, gDeltaTime);
    if (glfwGetKey(m_pWindow, GLFW_KEY_D) == GLFW_PRESS)
        g_pCamera->ProcessKeyboard(RIGHT, gDeltaTime);
    if (glfwGetKey(m_pWindow, GLFW_KEY_Q) == GLFW_PRESS)
        g_pCamera->ProcessKeyboard(UP, gDeltaTime);
    if (glfwGetKey(m_pWindow, GLFW_KEY_E) == GLFW_PRESS)
        g_pCamera->ProcessKeyboard(DOWN, gDeltaTime);

    // Projection toggling
    if (glfwGetKey(m_pWindow, GLFW_KEY_P) == GLFW_PRESS)
        bOrthographicProjection = false;
    if (glfwGetKey(m_pWindow, GLFW_KEY_O) == GLFW_PRESS)
        bOrthographicProjection = true;
}

/***********************************************************
 *  PrepareSceneView()
 *
 *  Prepares the scene view with the current camera view
 *  and projection settings.
 ***********************************************************/
void ViewManager::PrepareSceneView()
{
    if (!g_pCamera) return;

    // Set the camera position once to be farther away (no continuous orbit)
    static bool initialPositionSet = false;
    if (!initialPositionSet)
    {
        g_pCamera->Position = glm::vec3(0.0f, 10.0f, 25.0f);
        initialPositionSet = true;
    }

    // Calculate time between frames
    float currentFrame = glfwGetTime();
    gDeltaTime = currentFrame - gLastFrame;
    gLastFrame = currentFrame;

    // Handle keyboard inputs (WASD, QE, P/O toggles)
    ProcessKeyboardEvents();

    // Retrieve an updated view matrix from the camera
    glm::mat4 view = g_pCamera->GetViewMatrix();
    glm::mat4 projection;

    // Decide which projection to use: Orthographic or Perspective
    if (bOrthographicProjection)
    {
        // Orthographic
        projection = glm::ortho(
            -10.0f,   // left
            10.0f,   // right
            -10.0f,   // bottom
            10.0f,   // top
            0.1f,    // near
            100.0f   // far
        );
    }
    else
    {
        // Perspective
        projection = glm::perspective(
            glm::radians(g_pCamera->Zoom),
            static_cast<float>(WINDOW_WIDTH) / WINDOW_HEIGHT,
            0.1f,
            100.0f
        );
    }

    // Send view, projection, and camera position to the shader
    if (m_pShaderManager)
    {
        m_pShaderManager->setMat4Value(g_ViewName, view);
        m_pShaderManager->setMat4Value(g_ProjectionName, projection);
        m_pShaderManager->setVec3Value("viewPosition", g_pCamera->Position);
    }
}
