#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>
#include <iostream>

// Global shader variable names
namespace
{
    const char* g_ModelName = "model";          // Model matrix uniform
    const char* g_TextureValueName = "objectTexture";
    const char* g_UseTextureName = "bUseTexture";
    const char* g_UseLightingName = "bUseLighting";
}

// Constructor
SceneManager::SceneManager(ShaderManager* pShaderManager)
    : m_pShaderManager(pShaderManager), m_basicMeshes(new ShapeMeshes()), m_loadedTextures(0)
{
}

// Destructor
SceneManager::~SceneManager()
{
    DestroyGLTextures();      // Free texture memory
    if (m_basicMeshes)
    {
        delete m_basicMeshes; // Delete shape meshes
        m_basicMeshes = nullptr;
    }
    m_pShaderManager = nullptr;
    m_objectMaterials.clear();
}

// CreateGLTexture()
// Loads a texture from a file and creates an OpenGL texture object.
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
    int width = 0, height = 0, colorChannels = 0;
    GLuint textureID = 0;

    stbi_set_flip_vertically_on_load(true);
    unsigned char* image = stbi_load(filename, &width, &height, &colorChannels, 0);
    if (image)
    {
        glGenTextures(1, &textureID);
        glBindTexture(GL_TEXTURE_2D, textureID);

        // Set texture parameters
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

        GLenum format = (colorChannels == 3) ? GL_RGB : GL_RGBA;
        glTexImage2D(GL_TEXTURE_2D, 0, format, width, height, 0, format, GL_UNSIGNED_BYTE, image);
        glGenerateMipmap(GL_TEXTURE_2D);

        stbi_image_free(image);

        m_textureIDs[m_loadedTextures++] = { tag, textureID };
        return true;
    }

    std::cerr << "Failed to load texture: " << filename << "\n";
    return false;
}

// BindGLTextures()
// Binds all loaded textures to texture units.
void SceneManager::BindGLTextures()
{
    for (int i = 0; i < m_loadedTextures; ++i)
    {
        glActiveTexture(GL_TEXTURE0 + i);
        glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
    }
}

// DestroyGLTextures()
// Deletes all loaded textures from GPU memory.
void SceneManager::DestroyGLTextures()
{
    for (int i = 0; i < m_loadedTextures; ++i)
    {
        glDeleteTextures(1, &m_textureIDs[i].ID);
    }
}

// FindTextureID()
// Returns the texture ID for a given tag or -1 if not found.
int SceneManager::FindTextureID(std::string tag)
{
    for (int i = 0; i < m_loadedTextures; ++i)
    {
        if (m_textureIDs[i].tag == tag) return m_textureIDs[i].ID;
    }
    return -1;
}

// FindMaterial()
// Locate material by its tag and return its properties.
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
    for (const auto& mat : m_objectMaterials)
    {
        if (mat.tag == tag)
        {
            material = mat;
            return true;
        }
    }
    return false;
}

// SetTransformations()
// Applies scaling, rotation, and translation to objects before drawing.
void SceneManager::SetTransformations(glm::vec3 scale, float Xrot, float Yrot, float Zrot, glm::vec3 position)
{
    glm::mat4 modelMatrix = glm::translate(position) *
        glm::rotate(glm::radians(Xrot), glm::vec3(1.0f, 0.0f, 0.0f)) *
        glm::rotate(glm::radians(Yrot), glm::vec3(0.0f, 1.0f, 0.0f)) *
        glm::rotate(glm::radians(Zrot), glm::vec3(0.0f, 0.0f, 1.0f)) *
        glm::scale(scale);

    m_pShaderManager->setMat4Value(g_ModelName, modelMatrix);
}

// SetShaderTexture()
// Activates and binds a texture for the shader.
void SceneManager::SetShaderTexture(std::string textureTag)
{
    int textureID = FindTextureID(textureTag);
    if (textureID >= 0)
    {
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, textureID);
        m_pShaderManager->setIntValue(g_UseTextureName, true);
    }
    else
    {
        m_pShaderManager->setIntValue(g_UseTextureName, false);
    }
}

// SetShaderMaterial()
// Passes material properties to the shader.
void SceneManager::SetShaderMaterial(std::string materialTag)
{
    OBJECT_MATERIAL material;
    if (FindMaterial(materialTag, material))
    {
        m_pShaderManager->setVec3Value("material.ambientColor", material.ambientColor);
        m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
        m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
        m_pShaderManager->setFloatValue("material.ambientStrength", material.ambientStrength);
        m_pShaderManager->setFloatValue("material.shininess", material.shininess);
    }
}

// DefineObjectMaterials()
// Defines materials for the plane, table, and NEW objects.
void SceneManager::DefineObjectMaterials()
{
    // Material for the floor (plane) - reflective surface
    {
        OBJECT_MATERIAL floorMat;
        floorMat.tag = "floorMaterial";
        floorMat.ambientColor = glm::vec3(0.3f, 0.3f, 0.3f);
        floorMat.diffuseColor = glm::vec3(0.7f, 0.7f, 0.7f);
        floorMat.specularColor = glm::vec3(1.0f, 1.0f, 1.0f);
        floorMat.ambientStrength = 0.2f;
        floorMat.shininess = 32.0f;
        m_objectMaterials.push_back(floorMat);
    }

    // Material for the table top (wood)
    {
        OBJECT_MATERIAL woodMat;
        woodMat.tag = "woodMaterial";
        woodMat.ambientColor = glm::vec3(0.4f, 0.2f, 0.1f);
        woodMat.diffuseColor = glm::vec3(0.6f, 0.3f, 0.2f);
        woodMat.specularColor = glm::vec3(0.2f, 0.2f, 0.2f);
        woodMat.ambientStrength = 0.2f;
        woodMat.shininess = 8.0f;
        m_objectMaterials.push_back(woodMat);
    }

    // Material for the table legs (metal)
    {
        OBJECT_MATERIAL metalMat;
        metalMat.tag = "metalMaterial";
        metalMat.ambientColor = glm::vec3(0.3f, 0.3f, 0.3f);
        metalMat.diffuseColor = glm::vec3(0.6f, 0.6f, 0.6f);
        metalMat.specularColor = glm::vec3(0.9f, 0.9f, 0.9f);
        metalMat.ambientStrength = 0.2f;
        metalMat.shininess = 64.0f;
        m_objectMaterials.push_back(metalMat);
    }

    // ---------------------------------------------------------
    // NEW: Materials for coffee cups, vase, flowers, lamp, shelf
    // ---------------------------------------------------------

    // Porcelain-like material for coffee cups
    {
        OBJECT_MATERIAL cupMat;
        cupMat.tag = "cupMaterial";
        cupMat.ambientColor = glm::vec3(0.8f, 0.8f, 0.9f);
        cupMat.diffuseColor = glm::vec3(0.9f, 0.9f, 1.0f);
        cupMat.specularColor = glm::vec3(1.0f, 1.0f, 1.0f);
        cupMat.ambientStrength = 0.3f;
        cupMat.shininess = 32.0f;
        m_objectMaterials.push_back(cupMat);
    }

    // Ceramic / glass-like for vase
    {
        OBJECT_MATERIAL vaseMat;
        vaseMat.tag = "vaseMaterial";
        vaseMat.ambientColor = glm::vec3(0.4f, 0.4f, 0.5f);
        vaseMat.diffuseColor = glm::vec3(0.5f, 0.5f, 0.7f);
        vaseMat.specularColor = glm::vec3(0.9f, 0.9f, 0.9f);
        vaseMat.ambientStrength = 0.2f;
        vaseMat.shininess = 64.0f;
        m_objectMaterials.push_back(vaseMat);
    }

    // Flower petal material
    {
        OBJECT_MATERIAL flowerMat;
        flowerMat.tag = "flowerMaterial";
        flowerMat.ambientColor = glm::vec3(0.8f, 0.2f, 0.2f);
        flowerMat.diffuseColor = glm::vec3(0.9f, 0.3f, 0.3f);
        flowerMat.specularColor = glm::vec3(0.9f, 0.9f, 0.9f);
        flowerMat.ambientStrength = 0.2f;
        flowerMat.shininess = 16.0f;
        m_objectMaterials.push_back(flowerMat);
    }

    // Lamp fixture material (could be metal or painted metal)
    {
        OBJECT_MATERIAL lampMat;
        lampMat.tag = "lampMaterial";
        lampMat.ambientColor = glm::vec3(0.3f, 0.3f, 0.3f);
        lampMat.diffuseColor = glm::vec3(0.6f, 0.6f, 0.6f);
        lampMat.specularColor = glm::vec3(1.0f, 1.0f, 1.0f);
        lampMat.ambientStrength = 0.2f;
        lampMat.shininess = 32.0f;
        m_objectMaterials.push_back(lampMat);
    }

    // Bookshelf material (wooden)
    {
        OBJECT_MATERIAL shelfMat;
        shelfMat.tag = "shelfMaterial";
        shelfMat.ambientColor = glm::vec3(0.3f, 0.2f, 0.1f);
        shelfMat.diffuseColor = glm::vec3(0.5f, 0.3f, 0.2f);
        shelfMat.specularColor = glm::vec3(0.2f, 0.2f, 0.2f);
        shelfMat.ambientStrength = 0.2f;
        shelfMat.shininess = 16.0f;
        m_objectMaterials.push_back(shelfMat);
    }
}

// SetupSceneLights()
// Configures one or two lights to ensure nothing is in complete shadow.
void SceneManager::SetupSceneLights()
{
    // Enable lighting in the shader
    m_pShaderManager->setBoolValue(g_UseLightingName, true);

    // We will use two lights: one directional, one point
    m_pShaderManager->setIntValue("lightCount", 2);

    // Light 1: A directional, warm light (like sunlight from an angle)
    m_pShaderManager->setVec3Value("light[0].position", glm::vec3(-1.0f, -1.0f, -0.5f));
    m_pShaderManager->setVec3Value("light[0].color", glm::vec3(1.0f, 0.9f, 0.8f));
    m_pShaderManager->setFloatValue("light[0].ambientIntensity", 0.2f);
    m_pShaderManager->setFloatValue("light[0].diffuseIntensity", 0.7f);
    m_pShaderManager->setFloatValue("light[0].specularIntensity", 0.5f);

    // Light 2: A point light to fill shadows
    m_pShaderManager->setVec3Value("light[1].position", glm::vec3(0.0f, 5.0f, 5.0f));
    m_pShaderManager->setVec3Value("light[1].color", glm::vec3(0.7f, 0.8f, 1.0f));
    m_pShaderManager->setFloatValue("light[1].ambientIntensity", 0.1f);
    m_pShaderManager->setFloatValue("light[1].diffuseIntensity", 0.5f);
    m_pShaderManager->setFloatValue("light[1].specularIntensity", 0.3f);
}

// PrepareScene()
// Loads meshes, textures, defines materials, and sets up lights.
void SceneManager::PrepareScene()
{
    // Load basic shapes (plane, box, cylinder, sphere).
    m_basicMeshes->LoadPlaneMesh();
    m_basicMeshes->LoadBoxMesh();
    m_basicMeshes->LoadCylinderMesh();
    m_basicMeshes->LoadSphereMesh();

    // Load textures
    CreateGLTexture("textures/wood.jpg", "wood_texture");
    CreateGLTexture("textures/metal.jpg", "metal_texture");
    CreateGLTexture("textures/floor.jpg", "floor_texture");

    //   - coffee cup pattern or color
    //   - vase or lamp
    //   - bookshelf wood
    // For example:
    CreateGLTexture("textures/white_porcelain.jpg", "cup_texture");
    CreateGLTexture("textures/flower.jpg", "flower_texture");
    CreateGLTexture("textures/wood_shelf.jpg", "shelf_texture");
    // ...adjust these file paths as needed

    // Define materials and lights
    DefineObjectMaterials();
    SetupSceneLights();
}

// Renders the floor plane with floor material and texture.
void SceneManager::RenderPlane()
{
    glm::vec3 scale(20.0f, 1.0f, 20.0f);
    glm::vec3 position(0.0f, -5.0f, 0.0f);

    SetTransformations(scale, 0.0f, 0.0f, 0.0f, position);
    SetShaderMaterial("floorMaterial");
    SetShaderTexture("floor_texture");
    m_basicMeshes->DrawPlaneMesh();
}

// Renders the four legs of the table with metal material.
void SceneManager::RenderTableLegs()
{
    glm::vec3 scaleXYZ(0.5f, 4.0f, 0.5f);
    glm::vec3 legPositions[] = {
        glm::vec3(-4.5f, -2.0f, -2.5f),
        glm::vec3(4.5f, -2.0f, -2.5f),
        glm::vec3(-4.5f, -1.5f,  3.5f),
        glm::vec3(4.5f, -1.5f,  3.5f)
    };

    SetShaderMaterial("metalMaterial");
    SetShaderTexture("metal_texture");

    for (const auto& legPos : legPositions)
    {
        SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, legPos);
        m_basicMeshes->DrawCylinderMesh();
    }
}

// Renders the tabletop with wood material.
void SceneManager::RenderTableTop()
{
    glm::vec3 scale(10.0f, 0.5f, 8.0f);
    glm::vec3 position(0.0f, 3.0f, 1.0f);

    SetTransformations(scale, 0.0f, 0.0f, 0.0f, position);
    SetShaderMaterial("woodMaterial");
    SetShaderTexture("wood_texture");
    m_basicMeshes->DrawBoxMesh();
}

// ----------------------------------------------------------------------------
// NEW METHODS: Render additional objects (coffee cups, vase, flowers, lamp, shelf)
// ----------------------------------------------------------------------------

// Render a coffee cup using a cylinder (body) + small cylinder or sphere as handle
void SceneManager::RenderCoffeeCup(const glm::vec3& position, float rotationY)
{
    // Cup Body
    {
        glm::vec3 scaleBody(0.5f, 0.7f, 0.5f);
        SetTransformations(scaleBody, 0.0f, rotationY, 0.0f, position);
        SetShaderMaterial("cupMaterial");
        SetShaderTexture("cup_texture"); // if you have a porcelain texture
        m_basicMeshes->DrawCylinderMesh();
    }

    // Cup Handle (approximate with a small cylinder)
    {
        // Offset the handle to the side
        glm::vec3 handlePos = position + glm::vec3(0.5f, 0.0f, 0.0f);
        glm::vec3 scaleHandle(0.1f, 0.3f, 0.1f);
        SetTransformations(scaleHandle, 0.0f, rotationY, 0.0f, handlePos);
        SetShaderMaterial("cupMaterial");
        SetShaderTexture("cup_texture");
        m_basicMeshes->DrawCylinderMesh();
    }
}

// Render a vase as a cylinder
void SceneManager::RenderVase(const glm::vec3& position)
{
    glm::vec3 scale(0.5f, 1.0f, 0.5f);
    SetTransformations(scale, 0.0f, 0.0f, 0.0f, position);
    SetShaderMaterial("vaseMaterial");
    // If you have a specific vase texture, use it:
    // SetShaderTexture("vase_texture");
    // else just set no texture or a placeholder
    SetShaderTexture("metal_texture"); // example fallback
    m_basicMeshes->DrawCylinderMesh();
}

// Render a single flower as a small sphere
// (You can call this multiple times for multiple flowers)
void SceneManager::RenderFlower(const glm::vec3& position)
{
    glm::vec3 scale(0.2f, 0.2f, 0.2f);
    SetTransformations(scale, 0.0f, 0.0f, 0.0f, position);
    SetShaderMaterial("flowerMaterial");
    SetShaderTexture("flower_texture"); // optional flower texture
    m_basicMeshes->DrawSphereMesh();
}

// Render a hanging lamp fixture as a sphere (lamp shade) + cylinder (stem)
void SceneManager::RenderLampFixture(const glm::vec3& position)
{
    // Lamp shade (sphere)
    {
        glm::vec3 scaleShade(0.8f, 0.8f, 0.8f);
        SetTransformations(scaleShade, 0.0f, 0.0f, 0.0f, position);
        SetShaderMaterial("lampMaterial");
        SetShaderTexture("metal_texture"); // or a lamp texture
        m_basicMeshes->DrawSphereMesh();
    }

    // Cylinder as the stem/rod above the lamp
    {
        glm::vec3 stemPos = position + glm::vec3(0.0f, 1.0f, 0.0f);
        glm::vec3 scaleStem(0.05f, 1.0f, 0.05f);
        SetTransformations(scaleStem, 0.0f, 0.0f, 0.0f, stemPos);
        SetShaderMaterial("lampMaterial");
        SetShaderTexture("metal_texture");
        m_basicMeshes->DrawCylinderMesh();
    }
}

// RenderScene()
// Renders the entire scene, ensuring that all objects are lit and textured.
void SceneManager::RenderScene()
{
    // 1. Render floor plane
    RenderPlane();

    // 2. Render table
    RenderTableLegs();
    RenderTableTop();

    // ---------------------------------------------------
    // 3. Render additional objects in the caf� scene
    // ---------------------------------------------------

    // Coffee cups (render two cups, for example)
    // Place them on the table: table top is at Y=3.0, so let's place cups slightly above that
    RenderCoffeeCup(glm::vec3(-1.0f, 3.6f, 1.0f), 30.0f); // cup #1
    RenderCoffeeCup(glm::vec3(1.0f, 3.6f, 1.0f), -45.0f); // cup #2

    // Vase (centered on the table, behind the cups)
    RenderVase(glm::vec3(0.0f, 3.5f, -1.0f));
    // Flowers in the vase (several small spheres above the vase top)
    RenderFlower(glm::vec3(0.0f, 4.8f, -1.0f)); // flower #1
    RenderFlower(glm::vec3(0.1f, 4.7f, -1.1f)); // flower #2
    RenderFlower(glm::vec3(-0.1f, 4.9f, -0.9f)); // flower #3

    // Hanging lamp fixture (over the table)
    RenderLampFixture(glm::vec3(0.0f, 8.0f, 0.0f));
}
