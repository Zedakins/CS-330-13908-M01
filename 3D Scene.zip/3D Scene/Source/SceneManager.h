#pragma once

#include "ShaderManager.h"
#include "ShapeMeshes.h"
#include <string>
#include <vector>
#include <glm/glm.hpp>

class SceneManager
{
public:
    SceneManager(ShaderManager* pShaderManager);
    ~SceneManager();

    // Structure to hold texture info
    struct TEXTURE_INFO
    {
        std::string tag;
        uint32_t ID;
    };

    // Structure for material properties (Phong model)
    struct OBJECT_MATERIAL
    {
        glm::vec3 ambientColor = glm::vec3(0.0f);
        glm::vec3 diffuseColor = glm::vec3(0.0f);
        glm::vec3 specularColor = glm::vec3(0.0f);
        float ambientStrength = 0.0f;
        float shininess = 1.0f;
        std::string tag;
    };

    // Prepare the scene by loading meshes, textures, and setting up lights and materials
    void PrepareScene();
    // Render all objects in the scene with lighting and materials
    void RenderScene();

    // Create an OpenGL texture from an image file
    bool CreateGLTexture(const char* filename, std::string tag);

private:
    ShaderManager* m_pShaderManager;    // Pointer to the shader manager
    ShapeMeshes* m_basicMeshes;         // Pointer to shape meshes

    int m_loadedTextures;               // Number of loaded textures
    TEXTURE_INFO m_textureIDs[16];      // Loaded texture info array

    std::vector<OBJECT_MATERIAL> m_objectMaterials; // Materials defined for objects

    // Methods for handling textures
    void BindGLTextures();
    void DestroyGLTextures();
    int FindTextureID(std::string tag);

    // Methods for transformations and textures
    void SetTransformations(glm::vec3 scaleXYZ, float XrotationDegrees, float YrotationDegrees, float ZrotationDegrees, glm::vec3 positionXYZ);
    void SetShaderTexture(std::string textureTag);

    // Materials and lighting
    bool FindMaterial(std::string tag, OBJECT_MATERIAL& material);
    void SetShaderMaterial(std::string materialTag);
    void DefineObjectMaterials();
    void SetupSceneLights();

    // Individual render methods for existing objects
    void RenderPlane();
    void RenderTableLegs();
    void RenderTableTop();

    // ---------------------------------------------------------------------
    // NEW: Individual render methods for additional objects
    // ---------------------------------------------------------------------
    void RenderCoffeeCup(const glm::vec3& position, float rotationY);
    void RenderVase(const glm::vec3& position);
    void RenderFlower(const glm::vec3& position);
    void RenderLampFixture(const glm::vec3& position);
};
